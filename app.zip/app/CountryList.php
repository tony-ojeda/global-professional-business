<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CountryList extends Model
{
    //
}
