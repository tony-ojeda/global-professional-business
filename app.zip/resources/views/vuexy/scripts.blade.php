<script src="{{ asset('vuexy/vendors/js/vendors.min.js') }}"></script>
<script src="{{ asset('vuexy/vendors/js/ui/prism.min.js') }}"></script>
@yield('vendor-script')
<script src="{{ asset('vuexy/vendors/js/extensions/sweetalert2.all.min.js') }}"></script>
<script src="{{ asset('vuexy/js/core/app-menu.js') }}"></script>
<script src="{{ asset('vuexy/js/core/app.js') }}"></script>
<script src="{{ asset('vuexy/js/scripts/components.js') }}"></script>
<script src="{{ asset('vuexy/js/scripts/customizer.js') }}"></script>
<script src="{{ asset('vuexy/js/scripts/footer.js') }}"></script>
<script src="{{ asset('backend/js/app.js') }}"></script>
@yield('page-script')